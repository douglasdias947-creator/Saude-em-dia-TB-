# Saúde em Dia — Android

Aplicativo educativo de saúde pública, com foco em prevenção, adesão ao tratamento da tuberculose e uso consciente de rastreamentos.

## O que já está implementado

- Interface Android nativa em Kotlin + Jetpack Compose + Material 3.
- Menu lateral + barra inferior com navegação.
- Tela inicial com mini feed e acesso rápido.
- **Diário da tuberculose**:
  - plano de 180 dias;
  - calendário para marcar cada tomada;
  - percentual de adesão e contador de tomadas;
  - explicação visual sobre melhora dos sintomas x eliminação da bactéria;
  - registro de efeitos adversos;
  - orientação sobre urina/suor avermelhado associado à rifampicina;
  - lembrete diário local;
  - apoio ao acompanhamento pela equipe/TDO.
- **Guia descomplicado de rastreamento do câncer**:
  - mama;
  - colo do útero;
  - colorretal;
  - próstata;
  - seção "não faça no automático" para marcadores tumorais e exames sem indicação;
  - diferença entre rastreamento e investigação diagnóstica;
  - sinais de alerta e urgência.
- **Minha saúde**:
  - checklist educativo de vacinas;
  - espaço para perguntas de consulta;
  - acesso ao SAMU 192;
  - atalho para Ministério da Saúde.
- **Acessibilidade**:
  - texto maior;
  - alto contraste;
  - ícones grandes;
  - áreas de toque confortáveis;
  - linguagem simples.
- Registros do diário e anotações são locais no aparelho nesta versão; não existe servidor nem cadastro obrigatório.

## Como abrir

1. Abra esta pasta no Android Studio.
2. Aguarde o Gradle sincronizar e baixar as dependências.
3. Execute em um aparelho Android ou emulador.
4. O projeto usa `minSdk 26` e `targetSdk 35`.

## Observação clínica

Este é um protótipo educacional. Ele não diagnostica, não prescreve, não modifica esquemas terapêuticos e não substitui consulta ou protocolos locais.

As informações de rastreamento foram estruturadas para refletir fontes públicas brasileiras consultadas em setembro de 2026. Diretrizes devem ser atualizadas quando o Ministério da Saúde/INCA publicar novas recomendações.

## Fontes principais

- Ministério da Saúde — Tuberculose:
  https://www.gov.br/saude/pt-br/assuntos/saude-de-a-a-z/t/tuberculose
- Ministério da Saúde — Tratamento da tuberculose:
  https://www.gov.br/aids/pt-br/assuntos/tuberculose/tratamento
- INCA — Detecção precoce do câncer do colo do útero:
  https://www.gov.br/inca/pt-br/assuntos/gestor-e-profissional-de-saude/controle-do-cancer-do-colo-do-utero/acoes/deteccao-precoce
- INCA — Mamografia:
  https://www.gov.br/inca/pt-br/canais-de-atendimento/imprensa/releases/2025/posicionamento-oficial-do-instituto-nacional-de-cancer-inca-sobre-faixa-etaria-recomendada-para-mamografia-de-rastreio
- INCA — Câncer de próstata:
  https://www.gov.br/inca/pt-br/assuntos/noticias/2023/ministerio-da-saude-recomenda-o-nao-rastreamento-populacional-do-cancer-de-proposta
- INCA — Rastreamento colorretal:
  https://www.gov.br/inca/pt-br/assuntos/noticias/2026/sus-adota-novo-exame-para-detectar-cancer-de-intestino-antes-de-sintomas

## Próximas evoluções recomendadas

1. Sincronização opcional com uma conta do SUS/serviço de saúde, somente com consentimento.
2. Modo profissional para equipe acompanhar adesão mediante autorização do paciente.
3. Exportação do diário em PDF para levar à consulta.
4. Calendário de vacinação individualizado.
5. Localizador de unidades de saúde e horários.
6. Áudio de leitura das telas para pessoas com baixa visão ou baixa alfabetização.
7. Conteúdo em Libras e linguagem ainda mais visual.
8. Modo "cuidador/família" com permissões granulares.
9. Atualização remota e versionada das recomendações clínicas.
