
package br.com.saudeemdia

import android.app.*
import android.content.*
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.navigation.compose.*
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

private val Blue = Color(0xFF0B5D7A)
private val Teal = Color(0xFF00796B)
private val LightBg = Color(0xFFF5FAFC)
private val DarkBg = Color(0xFF0D171C)
private val Orange = Color(0xFFE07A00)
private val Green = Color(0xFF237A4B)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch("android.permission.POST_NOTIFICATIONS")
        }
        setContent { SaudeEmDiaApp() }
    }
}

enum class Screen { HOME, TB, PREVENTION, HEALTH, SETTINGS }

@Composable
fun SaudeEmDiaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("saude", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf(Screen.HOME) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val drawerScope = rememberCoroutineScope()
    var largeText by remember { mutableStateOf(prefs.getBoolean("largeText", false)) }
    var highContrast by remember { mutableStateOf(prefs.getBoolean("contrast", false)) }
    var largeIcons by remember { mutableStateOf(prefs.getBoolean("icons", true)) }
    var reminder by remember { mutableStateOf(prefs.getBoolean("reminder", false)) }

    val fontScale = if (largeText) 1.18f else 1f
    val colors = if (highContrast) {
        darkColorScheme(
            primary = Color(0xFF9FE8FF), onPrimary = Color.Black,
            secondary = Color(0xFF9FF3D0), onSecondary = Color.Black,
            background = Color.Black, surface = Color(0xFF111111),
            onBackground = Color.White, onSurface = Color.White
        )
    } else {
        lightColorScheme(
            primary = Blue, secondary = Teal, background = LightBg,
            surface = Color.White, onSurface = Color(0xFF17313B)
        )
    }

    MaterialTheme(colorScheme = colors, typography = Typography().let {
        it.copy(
            bodyLarge = it.bodyLarge.copy(fontSize = it.bodyLarge.fontSize * fontScale),
            bodyMedium = it.bodyMedium.copy(fontSize = it.bodyMedium.fontSize * fontScale),
            titleLarge = it.titleLarge.copy(fontSize = it.titleLarge.fontSize * fontScale),
            titleMedium = it.titleMedium.copy(fontSize = it.titleMedium.fontSize * fontScale)
        )
    }) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet {
                    Spacer(Modifier.height(20.dp))
                    Text("Saúde em Dia", style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold, modifier = Modifier.padding(24.dp))
                    Text("Informação, prevenção e cuidado", modifier = Modifier.padding(horizontal = 24.dp))
                    Spacer(Modifier.height(16.dp))
                    DrawerItem("Início", Icons.Default.Home, screen == Screen.HOME) {
                        screen = Screen.HOME; drawerScope.launch { drawerState.close() }
                    }
                    DrawerItem("Diário da tuberculose", Icons.Default.Medication, screen == Screen.TB) {
                        screen = Screen.TB; drawerScope.launch { drawerState.close() }
                    }
                    DrawerItem("Guia de prevenção", Icons.Default.HealthAndSafety, screen == Screen.PREVENTION) {
                        screen = Screen.PREVENTION; drawerScope.launch { drawerState.close() }
                    }
                    DrawerItem("Minha saúde", Icons.Default.MonitorHeart, screen == Screen.HEALTH) {
                        screen = Screen.HEALTH; drawerScope.launch { drawerState.close() }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 10.dp))
                    DrawerItem("Configurações e acessibilidade", Icons.Default.Settings, screen == Screen.SETTINGS) {
                        screen = Screen.SETTINGS; drawerScope.launch { drawerState.close() }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Conteúdo educativo — não substitui avaliação profissional.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(24.dp))
                }
            }
        ) {
            Scaffold(
                topBar = {
                    CenterAlignedTopAppBar(
                        title = { Text(screenTitle(screen), fontWeight = FontWeight.Bold) },
                        navigationIcon = {
                            IconButton(onClick = { drawerScope.launch { drawerState.open() } }) {
                                Icon(Icons.Default.Menu, "Abrir menu")
                            }
                        },
                        actions = {
                            IconButton(onClick = { screen = Screen.SETTINGS }) {
                                Icon(Icons.Default.Settings, "Configurações")
                            }
                        }
                    )
                },
                bottomBar = {
                    NavigationBar {
                        BottomItem("Início", Icons.Default.Home, screen == Screen.HOME) { screen = Screen.HOME }
                        BottomItem("Diário", Icons.Default.CalendarMonth, screen == Screen.TB) { screen = Screen.TB }
                        BottomItem("Prevenção", Icons.Default.HealthAndSafety, screen == Screen.PREVENTION) { screen = Screen.PREVENTION }
                        BottomItem("Menu", Icons.Default.Menu, screen == Screen.HEALTH || screen == Screen.SETTINGS) { drawerScope.launch { drawerState.open() } }
                    }
                }
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    when (screen) {
                        Screen.HOME -> HomeScreen(onTB = { screen = Screen.TB }, onPrevention = { screen = Screen.PREVENTION })
                        Screen.TB -> TbDiaryScreen(prefs, largeIcons)
                        Screen.PREVENTION -> PreventionScreen()
                        Screen.HEALTH -> HealthScreen()
                        Screen.SETTINGS -> SettingsScreen(
                            largeText, highContrast, largeIcons,
                            onLargeText = { largeText = it; prefs.edit().putBoolean("largeText", it).apply() },
                            onContrast = { highContrast = it; prefs.edit().putBoolean("contrast", it).apply() },
                            onIcons = { largeIcons = it; prefs.edit().putBoolean("icons", it).apply() },
                            reminder = reminder,
                            onReminder = {
                                reminder = it
                                prefs.edit().putBoolean("reminder", it).apply()
                                if (it) scheduleDailyReminder(context) else cancelDailyReminder(context)
                            }
                        )
                    }
                }
            }
        }
    }
}

fun screenTitle(screen: Screen) = when(screen) {
    Screen.HOME -> "Saúde em Dia"
    Screen.TB -> "Diário da tuberculose"
    Screen.PREVENTION -> "Guia de prevenção"
    Screen.HEALTH -> "Minha saúde"
    Screen.SETTINGS -> "Configurações"
}

@Composable
fun DrawerItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(label) },
        icon = { Icon(icon, null) },
        selected = selected,
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp)
    )
}

@Composable
fun BottomItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(selected = selected, onClick = onClick, icon = { Icon(icon, label) }, label = { Text(label) })
}

@Composable
fun HomeScreen(onTB: () -> Unit, onPrevention: () -> Unit) {
    val context = LocalContext.current
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Cuidar hoje facilita o amanhã.", style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Um guia simples para acompanhar tratamentos, entender exames e prevenir doenças.")
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = onTB, label = { Text("Diário TB") }, leadingIcon = { Icon(Icons.Default.Medication, null) })
                        AssistChip(onClick = onPrevention, label = { Text("Prevenção") }, leadingIcon = { Icon(Icons.Default.Shield, null) })
                    }
                }
            }
        }
        item {
            SectionTitle("Acesso rápido")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction("Tuberculose", Icons.Default.Medication, onTB, Modifier.weight(1f))
                QuickAction("Rastreamento", Icons.Default.Search, onPrevention, Modifier.weight(1f))
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Newspaper, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text("Mini feed", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(10.dp))
                    FeedItem("TB", "Sentir-se melhor não significa que a infecção já foi eliminada. Complete o tratamento prescrito.")
                    FeedItem("Prevenção", "Nem todo exame é um bom exame de rastreamento. A idade e o risco mudam a indicação.")
                    FeedItem("SUS", "O aplicativo não substitui a equipe: use a unidade de saúde para dúvidas, sintomas ou efeitos adversos.")
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(18.dp)) {
                    Text("🚨 Quando procurar ajuda", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Falta de ar intensa, dor no peito forte, desmaio, confusão, convulsão ou piora rápida precisam de avaliação urgente.")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:192"))
                        context.startActivity(intent)
                    }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Phone, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Ligar para o SAMU 192")
                    }
                }
            }
        }
        item { DisclaimerCard() }
    }
}

@Composable fun FeedItem(tag: String, text: String) {
    Row(Modifier.padding(vertical = 7.dp), verticalAlignment = Alignment.Top) {
        AssistChip(onClick = {}, label = { Text(tag) })
        Spacer(Modifier.width(10.dp))
        Text(text, modifier = Modifier.weight(1f))
    }
}

@Composable fun QuickAction(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier) {
    OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 90.dp), shape = RoundedCornerShape(18.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(5.dp))
            Text(label, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun TbDiaryScreen(prefs: android.content.SharedPreferences, largeIcons: Boolean) {
    var startDate by remember { mutableStateOf(LocalDate.parse(prefs.getString("tbStart", LocalDate.now().toString())!!)) }
    var showDatePicker by remember { mutableStateOf(false) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var showEffects by remember { mutableStateOf(false) }
    val pickerState = rememberDatePickerState(
        initialSelectedDateMillis = startDate.toEpochDay() * 86_400_000L
    )
    val doses = remember { mutableStateMapOf<String, Boolean>() }
    val effects = remember { mutableStateMapOf<String, Set<String>>() }
    val total = 180
    val days = (0 until total).map { startDate.plusDays(it.toLong()) }
    val completed = days.count { doses[it.toString()] == true }
    val percent = if (days.isEmpty()) 0 else ((completed.toDouble() / days.size) * 100).roundToInt()
    val todayInPlan = !LocalDate.now().isBefore(startDate) && !LocalDate.now().isAfter(startDate.plusDays(179))
    val todayDone = doses[LocalDate.now().toString()] == true

    LaunchedEffect(startDate) {
        doses.clear()
        days.forEach { day ->
            if (prefs.getBoolean("dose_${day}", false)) doses[day.toString()] = true
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { millis ->
                        startDate = Instant.ofEpochMilli(millis)
                            .atZone(ZoneId.systemDefault()).toLocalDate()
                        prefs.edit().putString("tbStart", startDate.toString()).apply()
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDatePicker = false }) { Text("Cancelar") } }
        ) { DatePicker(state = pickerState) }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Seu tratamento tem uma rotina.", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Marque cada tomada. O diário é um apoio de memória e acompanhamento — não altera a prescrição.")
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Stat("Adesão", "$percent%")
                        Stat("Tomadas", "$completed")
                        Stat("Plano", "180 dias")
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Por que não posso parar quando melhoro?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Os sintomas podem desaparecer antes de a bactéria ser eliminada. O tratamento irregular favorece falha e resistência aos medicamentos.")
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🦠", fontSize = 36.sp)
                        Spacer(Modifier.width(12.dp))
                        Text("Pense na bactéria como um inimigo que pode ficar menos ativo: melhorar não é o mesmo que terminar a guerra.")
                    }
                }
            }
        }
        item {
            SectionTitle("Calendário do tratamento")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Event, null)
                Spacer(Modifier.width(8.dp))
                Text("Início: ${startDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))}")
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showDatePicker = true }) { Text("Alterar") }
            }
        }
        item {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(64.dp),
                modifier = Modifier.height(440.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(days) { day ->
                    val done = doses[day.toString()] == true
                    val isToday = day == LocalDate.now()
                    OutlinedButton(
                        onClick = {
                            selectedDate = day
                            doses[day.toString()] = !done
                            prefs.edit().putBoolean("dose_${day}", !done).apply()
                        },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(4.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (done) Color(0xFFD9F4E3) else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(day.dayOfMonth.toString(), fontWeight = FontWeight.Bold)
                            Text(
                                if (done) "✓" else if (isToday) "Hoje" else day.monthValue.toString(),
                                fontSize = if (largeIcons) 13.sp else 11.sp
                            )
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { showEffects = !showEffects }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Warning, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Efeitos")
                }
                OutlinedButton(onClick = {
                    if (todayInPlan) {
                        doses[LocalDate.now().toString()] = true
                        prefs.edit().putBoolean("dose_${LocalDate.now()}", true).apply()
                    }
                }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.CheckCircle, null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (todayDone) "Tomado ✓" else "Marcar hoje")
                }
            }
        }
        if (showEffects) {
            item { SideEffectsCard(effects, selectedDate) }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Acompanhamento com a equipe", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp))
                    Text("Leve este registro para sua unidade. O Tratamento Diretamente Observado (TDO) pode ser combinado com a equipe e também pode usar tecnologias, conforme a organização do serviço.")
                }
            }
        }
        item { DisclaimerCard() }
    }
}

@Composable fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SideEffectsCard(effects: SnapshotStateMap<String, Set<String>>, selectedDate: LocalDate) {
    val options = listOf("Náusea", "Dor abdominal", "Coceira leve", "Dor articular", "Urina avermelhada", "Outro")
    val selected = effects[selectedDate.toString()] ?: emptySet()
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(18.dp)) {
            Text("Registre para conversar com a equipe", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(selectedDate.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")))
            options.forEach { option ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(
                        checked = selected.contains(option),
                        onCheckedChange = {
                            effects[selectedDate.toString()] =
                                if (it) selected + option else selected - option
                        }
                    )
                    Text(option)
                }
            }
            Spacer(Modifier.height(5.dp))
            Text("A urina/suor alaranjado-avermelhado pode ocorrer com rifampicina. Outros sintomas, especialmente icterícia, alteração visual importante ou reação intensa, devem ser comunicados prontamente à equipe.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun PreventionScreen() {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf("Rastreamento", "Não faça no automático", "Sinais de alerta")
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Guia descomplicado", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text("A melhor prevenção não é pedir todos os exames: é fazer os exames certos, na idade e no risco certos.")
        }
        item {
            PrimaryTabRow(selectedTabIndex = tab) {
                tabs.forEachIndexed { i, title -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(title) }) }
            }
        }
        when(tab) {
            0 -> {
                item { ScreeningCard("Câncer de mama", "50–74 anos", "Mamografia de rastreamento a cada 2 anos para a população-alvo, conforme recomendação atual do Ministério da Saúde/INCA. Fora da faixa, a indicação deve ser individualizada.", Icons.Default.Female) }
                item { ScreeningCard("Colo do útero", "25–64 anos, com colo do útero e vida sexual", "O rastreamento organizado passou a priorizar teste molecular para DNA-HPV; onde ele ainda não estiver disponível, o Papanicolau continua sendo utilizado.", Icons.Default.HealthAndSafety) }
                item { ScreeningCard("Câncer colorretal", "50–75 anos", "O SUS passou a adotar o Teste Imunoquímico Fecal (FIT) para pessoas assintomáticas nessa faixa; siga o fluxo local e não confunda rastreamento com investigação de sintomas.", Icons.Default.MedicalInformation) }
                item { ScreeningCard("Próstata", "Não há rastreamento populacional", "O Ministério da Saúde/INCA não recomenda PSA/toque como rastreamento de rotina para homens assintomáticos. Se houver interesse, a decisão deve ser compartilhada após discutir benefícios e danos.", Icons.Default.Male) }
            }
            1 -> {
                item { ScreeningCard("Marcadores tumorais", "Não são um check-up geral", "Exames como CEA, CA 19-9, CA-125 e outros não devem ser usados indiscriminadamente para rastrear câncer em pessoas assintomáticas. Podem ter usos específicos definidos pela equipe.", Icons.Default.Bloodtype) }
                item { ScreeningCard("Preventivo fora da indicação", "Idade e contexto importam", "Pedir um exame só porque ele existe pode gerar falso-positivo, ansiedade, procedimentos e sobrediagnóstico. O aplicativo ajuda a perguntar antes: para quem, quando e por quê?", Icons.Default.QuestionMark) }
                item { ScreeningCard("Exame ≠ diagnóstico", "Rastreamento é para assintomáticos", "Quem tem sintomas suspeitos precisa de avaliação diagnóstica, que é diferente do rastreamento populacional.", Icons.Default.Search) }
            }
            2 -> {
                item { AlertCard("Procure avaliação", "Sangue nas fezes ou urina, perda de peso inexplicada, sangramento persistente, caroço novo, mudança persistente do hábito intestinal, tosse/rouquidão prolongada ou dificuldade urinária merecem avaliação.", false) }
                item { AlertCard("Urgência", "Falta de ar intensa, dor torácica forte, desmaio, confusão, convulsão, sangramento volumoso ou piora rápida exigem atendimento imediato.", true) }
            }
        }
        item { PreventionHabits() }
        item { DisclaimerCard() }
        item {
            Text("Fontes: Ministério da Saúde e Instituto Nacional de Câncer (INCA). Conteúdo revisável conforme novas diretrizes.", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ScreeningCard(title: String, who: String, text: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, modifier = Modifier.size(34.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(who, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(Modifier.height(9.dp))
            Text(text)
        }
    }
}

@Composable fun AlertCard(title: String, text: String, emergency: Boolean) {
    Card(colors = CardDefaults.cardColors(containerColor = if (emergency) Color(0xFFFFE3E0) else MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.Top) {
            Icon(if (emergency) Icons.Default.Emergency else Icons.Default.Info, null, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(text)
            }
        }
    }
}

@Composable fun PreventionHabits() {
    Card(shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Text("Prevenção que cabe na vida real", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            val habits = listOf(
                "🚭 Evitar tabaco e fumaça",
                "🏃 Atividade física regular",
                "💉 Vacinas em dia",
                "🥗 Alimentação variada",
                "☀️ Proteção solar",
                "🦷 Cuidado odontológico",
                "🍺 Reduzir álcool",
                "🩺 Acompanhar pressão e fatores de risco"
            )
            habits.forEach { Text(it, modifier = Modifier.padding(vertical = 4.dp)) }
        }
    }
}

@Composable
fun HealthScreen() {
    val context = LocalContext.current
    var note by remember { mutableStateOf(prefsNote(context)) }
    var saved by remember { mutableStateOf(false) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Minha saúde", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Uma área simples para guardar lembretes pessoais no próprio aparelho.")
                }
            }
        }
        item {
            ActionCard("💉 Vacinas", "Checklist para conversar com sua unidade sobre calendário e doses atrasadas.", Icons.Default.Vaccines)
        }
        item {
            ActionCard("📅 Consultas e exames", "Anote datas, perguntas e resultados para não esquecer durante a consulta.", Icons.Default.Event)
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Perguntas para sua próxima consulta", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(note, { note = it }, label = { Text("Ex.: o que preciso acompanhar?") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        context.getSharedPreferences("saude", Context.MODE_PRIVATE)
                            .edit().putString("healthNote", note).apply()
                        saved = true
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (saved) "Salvo ✓" else "Salvar no aparelho") }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Serviços rápidos", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = {
                        context.startActivity(Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:192")))
                    }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Phone, null); Spacer(Modifier.width(8.dp)); Text("SAMU 192")
                    }
                    Spacer(Modifier.height(7.dp))
                    OutlinedButton(onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.gov.br/saude/pt-br"))
                        context.startActivity(intent)
                    }, modifier = Modifier.fillMaxWidth()) { Text("Abrir Ministério da Saúde") }
                }
            }
        }
    }
}

@Composable fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(38.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(subtitle)
            }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

@Composable
fun SettingsScreen(
    largeText: Boolean, highContrast: Boolean, largeIcons: Boolean,
    onLargeText: (Boolean) -> Unit, onContrast: (Boolean) -> Unit, onIcons: (Boolean) -> Unit,
    reminder: Boolean, onReminder: (Boolean) -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Acessibilidade", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Feito para leitura fácil, toque confortável e diferentes necessidades.")
        }
        item { SettingSwitch("Texto maior", "Aumenta a leitura em todo o aplicativo.", Icons.Default.TextFields, largeText, onLargeText) }
        item { SettingSwitch("Alto contraste", "Aumenta o contraste visual das telas.", Icons.Default.Contrast, highContrast, onContrast) }
        item { SettingSwitch("Ícones grandes", "Prioriza elementos visuais maiores no diário.", Icons.Default.AccessibilityNew, largeIcons, onIcons) }
        item { SettingSwitch("Lembrete diário", "Mostra um lembrete no aparelho para registrar a rotina de saúde.", Icons.Default.Notifications, reminder, onReminder) }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Privacidade", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Os registros do diário são salvos localmente neste aparelho nesta versão. Não envie informações pessoais de saúde para pessoas ou serviços sem necessidade.")
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Sobre o conteúdo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("O app é educativo. Não diagnostica, não prescreve e não substitui consulta. Em caso de dúvida, procure sua equipe de saúde.")
                    Spacer(Modifier.height(8.dp))
                    Text("Versão 1.0 • conteúdo revisado com fontes públicas do Ministério da Saúde/INCA.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable fun SettingSwitch(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(34.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked, onCheckedChange = onChecked)
        }
    }
}

@Composable fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}

@Composable fun DisclaimerCard() {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.Info, null)
            Spacer(Modifier.width(9.dp))
            Text("Informação educativa. O aplicativo não substitui diagnóstico, prescrição ou acompanhamento profissional.")
        }
    }
}

@Composable fun SearchCard(title: String, text: String) = ScreeningCard(title, "", text, Icons.Default.Search)


fun reminderPendingIntent(context: Context): PendingIntent {
    return PendingIntent.getBroadcast(
        context, 7001,
        Intent(context, ReminderReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}

fun scheduleDailyReminder(context: Context) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 8)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
    }
    alarm.setInexactRepeating(
        AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY,
        reminderPendingIntent(context)
    )
}

fun cancelDailyReminder(context: Context) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarm.cancel(reminderPendingIntent(context))
}

fun prefsNote(context: Context): String =
    context.getSharedPreferences("saude", Context.MODE_PRIVATE).getString("healthNote", "") ?: ""

fun createNotificationChannel(context: Context) {
    if (android.os.Build.VERSION.SDK_INT >= 26) {
        val channel = NotificationChannel("health_reminders", "Lembretes de saúde", NotificationManager.IMPORTANCE_DEFAULT)
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}
